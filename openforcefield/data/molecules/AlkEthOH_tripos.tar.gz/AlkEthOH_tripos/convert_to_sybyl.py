"""
A script converting the original data in

https://github.com/openforcefield/open-forcefield-data/blob/master/Model-Systems/AlkEthOH_distrib/inputfiles.tar.gz

to remove the leap output files and convert GAFF atom types to SYBYL atom types.
"""

import glob
import os
import re


mol2s = glob.glob('./*/AlkEthOH_c*.mol2') + glob.glob('./*/AlkEthOH_r*.mol2')
non_sybyl_mol2s = [i for i in mol2s if re.search('.*_[rc][0-9]+.mol2', i)]

print(len(mol2s))
print(len(non_sybyl_mol2s))

# Create new mol2 files with SYBYL atom types.
for mol2 in non_sybyl_mol2s:
    outname = mol2.replace('.mol2','_tripos.mol2')
    if os.path.exists(outname):
        print("Skipping {} because it already exists".format(outname))
        continue
    cmd = 'antechamber -i {} -fi mol2 -o {} -fo mol2 -at sybyl'.format(mol2, outname)
    print(cmd)
    os.system(cmd)

# Remove mol2 files with GAFF atom types.
for mol2_file_path in non_sybyl_mol2s:
    os.remove(mol2_file_path)

# Delete all leap files.
leap_file_paths = glob.glob('./*/*.leap_in') + glob.glob('./*/leap_lig.*')
for leap_file_path in leap_file_paths:
    os.remove(leap_file_path)